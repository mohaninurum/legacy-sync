import 'package:legacy_sync/features/list_of_module/data/model/list_of_module_model.dart';

class ListOfModuleState {
  final bool isLoading;
  final QuestionData data;
  final int totalAnswered;
  final String? errorMessage;
  final QuestionItems currentQuestionItems;

  const ListOfModuleState({required this.isLoading, required this.data, required this.currentQuestionItems,required this.totalAnswered, this.errorMessage});

  factory ListOfModuleState.initial() => ListOfModuleState(isLoading: false, currentQuestionItems: QuestionItems.empty(),data: QuestionData.empty(),totalAnswered: 0);

  ListOfModuleState copyWith({bool? isSpeaking, bool? isLoading, QuestionData? data,QuestionItems? currentQuestionItems, String? errorMessage, int? totalAnswered}) {
    return ListOfModuleState(currentQuestionItems: currentQuestionItems ?? this.currentQuestionItems,isLoading: isLoading ?? this.isLoading, data: data ?? this.data, errorMessage: errorMessage ?? this.errorMessage, totalAnswered: totalAnswered ?? this.totalAnswered);
  }
}
