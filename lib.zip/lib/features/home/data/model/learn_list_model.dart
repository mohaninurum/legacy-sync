class LearnListModel{

}