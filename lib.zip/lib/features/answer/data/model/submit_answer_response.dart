class SubmitAnswerResponse {
  String? status;
  String? message;
  Data? data;
  SubmitAnswerResponse({
      this.status, 
      this.message, 
      this.data,});

  SubmitAnswerResponse.fromJson(dynamic json) {
    status = json['status'];
    message = json['message'];
    data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

SubmitAnswerResponse copyWith({  String? status,
  String? message,
  Data? data,
}) => SubmitAnswerResponse(  status: status ?? this.status,
  message: message ?? this.message,
  data: data ?? this.data,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['status'] = status;
    map['message'] = message;
    if (data != null) {
      map['data'] = data?.toJson();
    }
    return map;
  }

}

class Data {

  int? answerId;
  String? questionId;
  String? userId;
  String? answerType;
  dynamic answerText;
  String? answerMedia;
  Data({
      this.answerId, 
      this.questionId, 
      this.userId, 
      this.answerType, 
      this.answerText, 
      this.answerMedia,});

  Data.fromJson(dynamic json) {
    answerId = json['answer_id'];
    questionId = json['question_id'];
    userId = json['user_id'];
    answerType = json['answer_type'];
    answerText = json['answer_text'];
    answerMedia = json['answer_media'];
  }

Data copyWith({  int? answerId,
  String? questionId,
  String? userId,
  String? answerType,
  dynamic answerText,
  String? answerMedia,
}) => Data(  answerId: answerId ?? this.answerId,
  questionId: questionId ?? this.questionId,
  userId: userId ?? this.userId,
  answerType: answerType ?? this.answerType,
  answerText: answerText ?? this.answerText,
  answerMedia: answerMedia ?? this.answerMedia,
);
  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['answer_id'] = answerId;
    map['question_id'] = questionId;
    map['user_id'] = userId;
    map['answer_type'] = answerType;
    map['answer_text'] = answerText;
    map['answer_media'] = answerMedia;
    return map;
  }

}