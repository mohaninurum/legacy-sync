import 'package:legacy_sync/features/legacy_wrapped/data/model/legacy_wrapped_page.dart';

abstract class LegacyWrappedRepository {
  List<LegacyWrappedPageModel> getLegacyWrappedPages();
}
