import 'package:flutter/widgets.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTextFontStyle {
  static TextStyle dmSerifDisplay = GoogleFonts.dmSerifDisplay();
}
